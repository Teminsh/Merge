using UnityEngine;
using System.Collections.Generic;

public class CraftingManager : MonoBehaviour
{
    public List<CraftingRecipe> recipes;  // List of all possible recipes
    public InventoryManager inventoryManager;  // Reference to our InventoryManager

    public void TryCraft(Item item1, Item item2)
    {
        CraftingRecipe matchingRecipe = FindMatchingRecipe(item1, item2);
        if (matchingRecipe != null)
        {
            // If there's a match, craft the output items
            foreach (Item outputItem in matchingRecipe.outputItems)
            {
                inventoryManager.AddItem(outputItem);
            }
            // Remove the input items from the inventory
            inventoryManager.RemoveItem(item1);
            inventoryManager.RemoveItem(item2);

            // Here you could also handle the narrative pop-up
            // Example: DisplayCraftingResult(matchingRecipe);
        }
    }

    public CraftingRecipe FindMatchingRecipe(Item item1, Item item2)
    {
        foreach (CraftingRecipe recipe in recipes)
        {
            if ((recipe.input1 == item1 && recipe.input2 == item2) || (recipe.input1 == item2 && recipe.input2 == item1))
            {
                return recipe;
            }
        }
        return null;  // No match found
    }
}