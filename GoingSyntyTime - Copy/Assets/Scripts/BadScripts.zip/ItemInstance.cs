using UnityEngine;

public class ItemInstance : MonoBehaviour
{
    public Item item;
}