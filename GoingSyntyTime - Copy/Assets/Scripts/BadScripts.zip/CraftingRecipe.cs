using UnityEngine;
using System.Collections.Generic;

[CreateAssetMenu(menuName = "Inventory/CraftingRecipe")]
public class CraftingRecipe : ScriptableObject
{
    public Item input1;  // The first input item
    public Item input2;  // The second input item
    public List<Item> outputItems;  // A list of output items
}