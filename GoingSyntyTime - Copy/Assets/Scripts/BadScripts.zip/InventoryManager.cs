using UnityEngine;
using System.Collections.Generic;

public class InventoryManager : MonoBehaviour
{
    public List<Item> items = new List<Item>();
    public Transform inventoryContainer;  // The parent for all spawned items
    public CraftingManager craftingManager;

    private Item selectedItem;  
    private GameObject selectedItemVFX;

    public GameObject craftingSuccessVFXPrefab;  // VFX that appears when two items combine successfully

    private const int gridWidth = 5; // Define the width of the grid
    private float spacing = 2.0f; // Define the spacing between items

    void Awake()
    {
        foreach (Item presetItem in items)
        {
            InstantiateItem(presetItem);
        }
    }

    private void InstantiateItem(Item item)
    {
        items.Add(item); // Add to the list
        
        GameObject instance = Instantiate(item.itemPrefab, inventoryContainer);
        instance.name = item.itemName;

        int index = items.Count - 1; // Use the index after adding to the list
        int x = index % gridWidth;
        int z = index / gridWidth;

        instance.transform.localPosition = new Vector3(x * spacing, 0, z * spacing);
        instance.transform.localScale = item.itemSize;
        instance.transform.localEulerAngles = item.itemRotation;
    }

    public void AddItem(Item itemToAdd)
    {
        InstantiateItem(itemToAdd);
    }

    public void RemoveItem(Item itemToRemove)
    {
        if (items.Contains(itemToRemove))
        {
            items.Remove(itemToRemove);
            Transform itemTransform = inventoryContainer.Find(itemToRemove.itemName);
            if (itemTransform != null) Destroy(itemTransform.gameObject);
        }

        // After removing, we need to rearrange items
        for (int i = 0; i < items.Count; i++)
        {
            Transform itemTransform = inventoryContainer.Find(items[i].itemName);
            int x = i % gridWidth;
            int z = i / gridWidth;
            itemTransform.localPosition = new Vector3(x * spacing, 0, z * spacing);
        }
    }

    public void OnItemClicked(Item clickedItem)
    {
        Transform clickedItemTransform = inventoryContainer.Find(clickedItem.itemName);
        if (selectedItem == null) 
        {
            selectedItem = clickedItem;
            clickedItemTransform.localScale *= 1.1f;  
            if (clickedItem.selectionVFXPrefab)
            {
                selectedItemVFX = Instantiate(clickedItem.selectionVFXPrefab, clickedItemTransform.position, Quaternion.Euler(clickedItem.vfxRotation), clickedItemTransform);
                selectedItemVFX.transform.localScale = clickedItem.vfxScale;
            }
        }
        else 
        {
            CraftingRecipe matchingRecipe = craftingManager.FindMatchingRecipe(selectedItem, clickedItem);
            if (matchingRecipe != null)
            {
                foreach (Item outputItem in matchingRecipe.outputItems)
                {
                    AddItem(outputItem);
                }
                RemoveItem(selectedItem);
                RemoveItem(clickedItem);
                Instantiate(craftingSuccessVFXPrefab, clickedItemTransform.position, Quaternion.identity);
                Transform selectedItemTransform = inventoryContainer.Find(selectedItem.itemName);
                Instantiate(craftingSuccessVFXPrefab, selectedItemTransform.position, Quaternion.identity);
                selectedItem = null;
                Destroy(selectedItemVFX);
            }
            else
            {
                Transform selectedItemTransform = inventoryContainer.Find(selectedItem.itemName);
                selectedItemTransform.localScale /= 1.1f;
                Destroy(selectedItemVFX);
                selectedItem = null;
            }
        }
    }
}