using UnityEngine;

[CreateAssetMenu(menuName = "Inventory/Item")]
public class Item : ScriptableObject
{
    public string itemName;
    public GameObject itemPrefab;
    public Sprite itemIcon;
    public Vector3 itemSize = Vector3.one;
    public Vector3 itemRotation = Vector3.zero;
    public GameObject selectionVFXPrefab; // The VFX that appears when the item is selected
    public Vector3 vfxScale = Vector3.one; // VFX scale
    public Vector3 vfxRotation = Vector3.zero; // VFX rotation
}