using UnityEngine;

public class ItemInstance : MonoBehaviour
{
    public Item item;
    public int quantity = 1;

    public void IncrementQuantity()
    {
        if (quantity < item.maxStackSize)
        {
            quantity++;
            UpdateVisuals();
        }
    }

    public void DecrementQuantity()
    {
        if (quantity > 0)
        {
            quantity--;
            UpdateVisuals();
        }
    }

    private void UpdateVisuals()
    {
        // Update any visuals related to the quantity, such as a text label showing the quantity
    }
}
