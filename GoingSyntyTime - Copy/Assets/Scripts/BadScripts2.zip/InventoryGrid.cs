using System.Collections.Generic;
using UnityEngine;

public class InventoryGrid : MonoBehaviour
{
    public int width = 5;       // Width of the grid
    public int height = 5;      // Height of the grid
    public float spacing = 2f;  // Spacing between items

    private Vector3[,] gridPositions; 

    public GameObject[,] itemsInGrid;

    public void PlaceItemInGrid(GameObject item, Vector3 position)
    {
        // Logic to set the item in the grid based on its position
        int x = Mathf.FloorToInt(position.x / spacing);
        int z = Mathf.FloorToInt(Mathf.Abs(position.z / spacing));

        itemsInGrid[x, z] = item;
    }

    void Start()
    {
        gridPositions = new Vector3[width, height];
        itemsInGrid = new GameObject[width, height];

        InitializeGrid();
    }

    void InitializeGrid()
    {
        for (int x = 0; x < width; x++)
        {
            for (int z = 0; z < height; z++)
            {
                gridPositions[x, z] = new Vector3(x * spacing, 0, -z * spacing); // This is based on your request for positive X and negative Z
            }
        }
    }

    public Vector3 GetFirstAvailablePosition()
    {
        for (int x = 0; x < width; x++)
        {
            for (int z = 0; z < height; z++)
            {
                if (itemsInGrid[x, z] == null)
                    return gridPositions[x, z];
            }
        }
        return Vector3.zero; // Returns origin if grid is full, handle this case!
    }

    
    //... More functionalities can be added as required
}