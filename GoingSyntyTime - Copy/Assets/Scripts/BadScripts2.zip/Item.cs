using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Create New Item", fileName = "NewItem")]
public class Item : ScriptableObject
{
    public string itemName;         
    public GameObject itemPrefab;   
    public Vector3 defaultRotation; 
    public Vector3 defaultScale;    
    public Sprite icon;             
    public int maxStackSize = 99;   // New: Max count for this item in a stack
}
