using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MergeManager : MonoBehaviour
{
    // We might have a dictionary to map pairs of items to their merged result for faster lookups
    public Dictionary<(Item, Item), Item> mergeRules = new Dictionary<(Item, Item), Item>();

    public bool CanItemsMerge(Item item1, Item item2)
    {
        return mergeRules.ContainsKey((item1, item2)) || mergeRules.ContainsKey((item2, item1));
    }

    public Item GetMergedItem(Item item1, Item item2)
    {
        if (mergeRules.TryGetValue((item1, item2), out Item mergedItem) || mergeRules.TryGetValue((item2, item1), out mergedItem))
        {
            return mergedItem;
        }
        return null; // If items can't be merged
    }
}
