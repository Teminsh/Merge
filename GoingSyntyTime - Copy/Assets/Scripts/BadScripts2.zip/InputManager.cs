using UnityEngine;

public class InputManager : MonoBehaviour
{
    public Inventory inventory; // Reference to the inventory script
    private GameObject firstSelectedItem;
    private GameObject secondSelectedItem;

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            HandleItemClick();
        }
    }

    void HandleItemClick()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;

        if (Physics.Raycast(ray, out hit))
        {
            GameObject clickedItem = hit.collider.gameObject;

            // Assuming items have a script/component that helps identify them or their type
            if (clickedItem.CompareTag("Item")) 
            {
                if (firstSelectedItem == null)
                {
                    firstSelectedItem = clickedItem;
                }
                else if (secondSelectedItem == null)
                {
                    secondSelectedItem = clickedItem;
                    MergeItems();  // Attempt to merge items
                }
            }
        }
    }

    void MergeItems()
    {
        // Logic to merge items - We'd call functions from MergeManager
        // Clear firstSelectedItem and secondSelectedItem after merging or if merge was not possible
        firstSelectedItem = null;
        secondSelectedItem = null;
    }
}
