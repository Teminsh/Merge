using System.Collections.Generic;
using UnityEngine;

public class Inventory : MonoBehaviour
{
    public List<Item> currentItems = new List<Item>();  // List to track items in the inventory
    public InventoryGrid inventoryGrid;  // Reference to the grid script

    private void Start()
    {
        SpawnInitialItems();
    }

    void SpawnInitialItems()
    {
        foreach (Item item in currentItems)
        {
            SpawnItem(item);
        }
    }

    public void AddItem(Item newItem)
    {
        foreach (var slot in inventoryGrid.itemsInGrid)
        {
            if (slot != null)
            {
                ItemInstance instance = slot.GetComponent<ItemInstance>();
                if (instance && instance.item == newItem && instance.quantity < newItem.maxStackSize)
                {
                    instance.IncrementQuantity();
                    return;
                }
            }
        }

        // If we didn't find a slot to stack the item, spawn a new one
        SpawnItem(newItem);
    }

    public void SpawnItem(Item item)
    {
        Vector3 spawnPos = inventoryGrid.GetFirstAvailablePosition();
        GameObject spawnedItem = Instantiate(item.itemPrefab, spawnPos, Quaternion.Euler(item.defaultRotation));
        spawnedItem.transform.localScale = item.defaultScale;

        ItemInstance instance = spawnedItem.AddComponent<ItemInstance>();
        instance.item = item;

        inventoryGrid.PlaceItemInGrid(spawnedItem, spawnPos);
    }

    
    // You can add methods to add or remove items from the currentItems list, based on the game's requirements
}
